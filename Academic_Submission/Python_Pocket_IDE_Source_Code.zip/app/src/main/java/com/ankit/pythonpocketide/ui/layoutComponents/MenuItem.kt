
package com.ankit.pythonpocketide.ui.layoutComponents

data class MenuItem(
    val id:String, val title:String, val resID:Int, val clickable:()->Unit
)
