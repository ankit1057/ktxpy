package com.ankit.pythonpocketide.ui.theme

class EditorTheme {
    companion object {
        const val AbyssColor: String = "Abyss Color"
        const val DarculaTheme: String = "Dracula Theme"
        const val QuietLight: String = "Quiet Light"
    }
}