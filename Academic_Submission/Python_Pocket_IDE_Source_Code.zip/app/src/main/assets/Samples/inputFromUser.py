#To take Input from user we use input("") function 
#The value passed in input function will be shown as output before taking input
#for example->
sample=input("Enter your name: ")
print(f"Hello {sample}")