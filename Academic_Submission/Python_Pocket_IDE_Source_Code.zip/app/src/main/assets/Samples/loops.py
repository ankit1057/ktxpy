'''
while loop 
continues to execute command until provided condition is false
'''
a=0
while(a<100):
    print(a)
    a+=1
'''
for loop 
used mainly for indexing arrays etc
'''
Subject=["Science","Math","Hindi","English","SSt"]
for s in Subject:
    print(s)    