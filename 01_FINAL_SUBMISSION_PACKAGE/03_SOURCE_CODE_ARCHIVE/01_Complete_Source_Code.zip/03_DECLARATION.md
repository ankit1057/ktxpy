# DECLARATION

---

I, **Ankit**, Enrollment No. **O23MCA110241**, student of **Master of Computer Applications** (Batch: Jul 2023), hereby declare that the Major Project titled **"Python Pocket IDE: Advanced Mobile Integrated Development Environment for Python Programming"** submitted by me to the **Centre for Distance & Online Education, Chandigarh University** in partial fulfillment of the requirements for the degree of **Master of Computer Applications** is my original work.

I further declare that:

1. The work presented in this project report is authentic and carried out by me under the supervision of my project guide.

2. The project has not been submitted earlier either to this university or to any other university/institution for the award of any degree or diploma.

3. I have followed the university guidelines and maintained academic integrity throughout the project development.

4. The project acknowledges all sources of information and gives due credit to all contributors and original authors.

5. The enhanced version of KtxPy has been properly credited to the original developers (PsiCodes) and all modifications are clearly documented.

6. All the work carried out for this project is original except where specifically acknowledged and referenced.

Any violation of the above conditions will render me liable for appropriate action by the university authorities.

---

**Date:** ________________

**Place:** Mohali, Punjab

---

**Student Name:** Ankit  
**Enrollment No:** O23MCA110241  
**Batch:** Jul 2023  
**Programme:** Master of Computer Applications  
**Semester:** Fourth Semester  

**Signature:** ________________ 