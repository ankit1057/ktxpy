# CERTIFICATE

---

This is to certify that the Major Project titled **"Python Pocket IDE: Advanced Mobile Integrated Development Environment for Python Programming"** submitted by **Ankit**, Enrollment No. **O23MCA110241**, Batch **Jul 2023**, for the partial fulfillment of the requirements for the degree of **Master of Computer Applications** from **Chandigarh University** is a bonafide work carried out by him under my supervision and guidance.

The work embodied in this project has not been submitted elsewhere for the award of any degree or diploma to the best of my knowledge.

---

**Date:** ________________

**Place:** Mohali, Punjab

---

**Project Supervisor:**

**[Faculty Supervisor Name]**  
**Designation**  
**Department of Computer Science and Engineering**  
**Chandigarh University**

**Signature:** ________________

---

**External Examiner:**

**[External Examiner Name]**  
**Designation**  
**Institution**

**Signature:** ________________

---

**Internal Examiner:**

**[Internal Examiner Name]**  
**Designation**  
**Department of Computer Science and Engineering**  
**Chandigarh University**

**Signature:** ________________ 