# PYTHON POCKET IDE: ADVANCED MOBILE INTEGRATED DEVELOPMENT ENVIRONMENT FOR PYTHON PROGRAMMING

## Major Project Report
**Submitted in Partial Fulfillment of the Requirements for the Degree of**

## MASTER OF COMPUTER APPLICATIONS

**Submitted By:**
**ANKIT**
**Enrollment No.: O23MCA110241**
**Batch: Jul 2023 - Fourth Semester**

**Under the Guidance of:**
**[Faculty Supervisor Name]**
**Department of Computer Science and Engineering**

---

## CENTRE FOR DISTANCE & ONLINE EDUCATION
## CHANDIGARH UNIVERSITY
## MOHALI, PUNJAB

**Year: 2025**

---

**Subject Code:** 23ONMCR-753  
**Course Title:** Major Project  
**Credits:** 12

---

**Project Category:** Mobile Application Development  
**Technology Stack:** Kotlin, Jetpack Compose, Python 3.11.5  
**Platform:** Android Mobile Devices 