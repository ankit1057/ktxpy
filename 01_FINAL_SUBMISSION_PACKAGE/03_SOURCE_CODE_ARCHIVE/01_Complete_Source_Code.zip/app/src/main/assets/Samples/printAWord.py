#Anything you will pass to print parameter will be provided as output
print("Hello world")