n=int(input("Number of Design : "))
for i in range(n):
    for m in range(i):
        print("*", end= " ")
    print("\n")